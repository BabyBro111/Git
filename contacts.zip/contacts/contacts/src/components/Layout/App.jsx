import React from "react";
import ContactsFields from "../ContactsFields/ContactsFields";

function App() {
  return (
    <div>
      <ContactsFields />
    </div>
  );
}

export default App;
