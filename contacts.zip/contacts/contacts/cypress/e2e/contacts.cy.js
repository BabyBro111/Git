describe('Contacts App', () => {
    beforeEach(() => {
        cy.visit('/');
    });
    
    it('should add a new contact', () => {
        cy.get('[data-test=new-contact-button]').click();
        cy.get('[data-test=name-input]').type('John Doe');
        cy.get('[data-test=phone-input]').type('123456789');
        cy.get('[data-test=email-input]').type('john.doe@example.com');
        cy.get('[data-test=save-button]').click();
        cy.contains('John Doe').should('be.visible');
    });

    it('should edit an existing contact', () => {
        cy.get('[data-test=edit-contact-button]').first().click();
        cy.get('[data-test=name-input]').clear().type('Jane Doe');
        cy.get('[data-test=save-button]').click();
        cy.contains('Jane Doe').should('be.visible');
    });

    it('should delete a contact', () => {
        cy.get('[data-test=delete-contact-button]').first().click();
        cy.get('[data-test=confirm-delete-button]').click();
        cy.get('[data-test=contact-list]').should('not.contain', 'Jane Doe');
    });

    it('should sort contacts', () => {
        cy.get('[data-test=sort-button]').click();
        cy.get('[data-test=contact-list] li').first().should('contain', 'A');
    });
});
