﻿using System;

public class GameLogic
{
    private int targetNumber;
    public int Attempts { get; private set; }

    public GameLogic(int target)
    {
        targetNumber = target;
        Attempts = 0;
    }

    public string MakeGuess(int guess)
    {
        Attempts++;
        if (guess < targetNumber) return "Загадане число більше!";
        if (guess > targetNumber) return "Загадане число менше!";
        return $"Вітаю! Ви вгадали число {targetNumber} за {Attempts} спроб.";
    }
}
