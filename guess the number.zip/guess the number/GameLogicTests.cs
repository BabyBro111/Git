﻿using Xunit;

public class GameLogicTests
{
    [Fact]
    public void Test_Number_Is_Greater()
    {
        var game = new GameLogic(50);
        Assert.Equal("Загадане число більше!", game.MakeGuess(30));
    }

    [Fact]
    public void Test_Number_Is_Lower()
    {
        var game = new GameLogic(50);
        Assert.Equal("Загадане число менше!", game.MakeGuess(70));
    }

    [Fact]
    public void Test_Correct_Guess()
    {
        var game = new GameLogic(50);
        Assert.Equal("Вітаю! Ви вгадали число 50 за 1 спроб.", game.MakeGuess(50));
    }

    [Fact]
    public void Test_Attempt_Counter()
    {
        var game = new GameLogic(75);
        game.MakeGuess(30);
        game.MakeGuess(50);
        game.MakeGuess(75);
        Assert.Equal(3, game.Attempts);
    }

    [Fact]
    public void Test_First_Attempt_Success()
    {
        var game = new GameLogic(42);
        Assert.Equal("Вітаю! Ви вгадали число 42 за 1 спроб.", game.MakeGuess(42));
    }

    [Fact]
    public void Test_Multiple_Attempts()
    {
        var game = new GameLogic(20);
        game.MakeGuess(5);
        game.MakeGuess(10);
        game.MakeGuess(15);
        game.MakeGuess(20);
        Assert.Equal("Вітаю! Ви вгадали число 20 за 4 спроб.", game.MakeGuess(20));
    }

    [Fact]
    public void Test_Too_Low_Then_Correct()
    {
        var game = new GameLogic(33);
        game.MakeGuess(10);
        Assert.Equal("Вітаю! Ви вгадали число 33 за 2 спроб.", game.MakeGuess(33));
    }

    [Fact]
    public void Test_Too_High_Then_Correct()
    {
        var game = new GameLogic(88);
        game.MakeGuess(95);
        Assert.Equal("Вітаю! Ви вгадали число 88 за 2 спроб.", game.MakeGuess(88));
    }

    [Fact]
    public void Test_Exact_Boundaries()
    {
        var gameLow = new GameLogic(1);
        var gameHigh = new GameLogic(100);

        Assert.Equal("Вітаю! Ви вгадали число 1 за 1 спроб.", gameLow.MakeGuess(1));
        Assert.Equal("Вітаю! Ви вгадали число 100 за 1 спроб.", gameHigh.MakeGuess(100));
    }
}
