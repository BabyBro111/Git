﻿using System;

class Program
{
    static void Main()
    {
        Random random = new Random();
        int targetNumber = random.Next(1, 101); // Випадкове число 1-100
        int attempts = 0;
        bool isGuessed = false;

        Console.WriteLine("Гра 'Вгадай число'! Введiть число вiд 1 до 100.");

        while (!isGuessed)
        {
            Console.Write("Ваш варiант: ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int guess))
            {
                attempts++;

                if (guess < targetNumber)
                {
                    Console.WriteLine("Загадане число бiльше!");
                }
                else if (guess > targetNumber)
                {
                    Console.WriteLine("Загадане число менше!");
                }
                else
                {
                    Console.WriteLine($"Вiтаю! Ви вгадали число {targetNumber} за {attempts} спроб.");
                    isGuessed = true;
                }
            }
            else
            {
                Console.WriteLine("Будь ласка, введiть коректне число.");
            }
        }
    }
}
